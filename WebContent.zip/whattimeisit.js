function whattimeisit(){
	alert(new Date());
	
}